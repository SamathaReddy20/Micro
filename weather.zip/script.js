// DOM Elements
const searchInput = document.getElementById('search-input');
const searchBtn = document.getElementById('search-btn');
const locationBtn = document.getElementById('location-btn');
const cityName = document.getElementById('city-name');
const currentDate = document.getElementById('current-date');
const currentTemp = document.getElementById('current-temp');
const weatherIcon = document.getElementById('weather-icon');
const weatherDesc = document.getElementById('weather-description');
const windSpeed = document.getElementById('wind-speed');
const humidity = document.getElementById('humidity');
const feelsLike = document.getElementById('feels-like');
const pressure = document.getElementById('pressure');
const hourlyForecast = document.getElementById('hourly-forecast');
const weeklyForecast = document.getElementById('weekly-forecast');
const backgroundImage = document.getElementById('background-image');
const hourly24Btn = document.getElementById('hourly-24');
const hourly48Btn = document.getElementById('hourly-48');
const unitToggle = document.getElementById('unit-toggle');
const lastUpdated = document.getElementById('last-updated');
const suggestionsContainer = document.getElementById('weather-suggestions');
const radarAnimateBtn = document.getElementById('radar-animate');
const radarTypeSelect = document.getElementById('radar-type');
const weatherRadar = document.getElementById('weather-radar');
const searchResults = document.getElementById('search-results');
const liveLocationToggle = document.getElementById('live-location-toggle');
const liveLocationIndicator = document.getElementById('live-location-indicator');
// API Configuration
const apiKey = '2052a7cbc9ac4031539f83ce9b0f6b14';
const baseUrl = 'https://api.openweathermap.org/data/2.5';
const geoApiUrl = 'https://api.openweathermap.org/geo/1.0/direct';
const geoApiReverseUrl = 'https://api.openweathermap.org/geo/1.0/reverse';

// State
let searchDebounceTimer;
let currentUnit = 'celsius';
let currentCity = '';
let forecastData = null;
let radarAnimationInterval = null;
let isRadarAnimating = false;
let geocodingCache = {};

// Weather background mapping
const weatherBackgrounds = {
    'clear': 'sunny,day',
    'clouds': 'cloudy,sky',
    'rain': 'rain,storm',
    'thunderstorm': 'thunderstorm,lightning',
    'snow': 'snow,winter',
    'mist': 'fog,mist',
    'smoke': 'fog,haze',
    'haze': 'fog,haze',
    'dust': 'desert,sand',
    'fog': 'fog,mist',
    'default': 'weather,landscape'
};

// Initialize with default city
window.addEventListener('load', () => {
    fetchWeatherData('London');
});

// Event Listeners
searchInput.addEventListener('input', (e) => {
    searchLocations(e.target.value);
});
liveLocationToggle.addEventListener('change', toggleLiveLocation);
document.addEventListener('click', (e) => {
    if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
        searchResults.style.display = 'none';
    }
});

locationBtn.addEventListener('click', () => {
    if (liveLocationToggle.checked) {
        stopLiveLocation();
    } else {
        locationBtn.innerHTML = '<span class="loading-spinner"></span>';
        getLocationWeather(true).finally(() => {
            locationBtn.innerHTML = '<i class="fas fa-location-arrow"></i>';
        });
    }
});

searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        const city = searchInput.value.trim();
        if (city) {
            fetchWeatherData(city);
        }
    }
});

hourly24Btn.addEventListener('click', () => {
    hourly24Btn.classList.add('active');
    hourly48Btn.classList.remove('active');
    updateHourlyForecast(24);
});

hourly48Btn.addEventListener('click', () => {
    hourly48Btn.classList.remove('active');
    hourly48Btn.classList.add('active');
    updateHourlyForecast(48);
});

unitToggle.addEventListener('click', toggleTemperatureUnit);
radarAnimateBtn.addEventListener('click', toggleRadarAnimation);
radarTypeSelect.addEventListener('change', updateRadar);
locationBtn.addEventListener('click', getLocationWeather);

// Main Functions
async function fetchWeatherData(location) {
    try {
        // Show loading state
        cityName.textContent = 'Loading...';
        currentTemp.textContent = '--';
        
        let lat, lon, displayName;
        
        if (typeof location === 'object' && location.lat && location.lon) {
            lat = location.lat;
            lon = location.lon;
            displayName = location.name;
            
            if (location.type) {
                displayName += ` (${location.type})`;
            }
        } else {
            const geoData = await geocodeLocation(location);
            if (!geoData) throw new Error('Location not found');
            
            lat = geoData.lat;
            lon = geoData.lon;
            displayName = geoData.name;
            
            if (geoData.type) {
                displayName += ` (${geoData.type})`;
            }
        }
        
        // Current weather
        const currentResponse = await fetch(
            `${baseUrl}/weather?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`
        );
        
        if (!currentResponse.ok) {
            const errorData = await currentResponse.json();
            throw new Error(errorData.message || 'Failed to fetch weather data');
        }
        
        const currentData = await currentResponse.json();
        currentCity = displayName;
        
        // Forecast
        const forecastResponse = await fetch(
            `${baseUrl}/forecast?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`
        );
        
        if (!forecastResponse.ok) {
            throw new Error('Failed to fetch forecast data');
        }
        
        forecastData = await forecastResponse.json();
        
        if (!forecastData.city) {
            forecastData.city = {
                name: displayName,
                coord: { lat, lon }
            };
        }
        
        updateCurrentWeather(currentData);
        updateHourlyForecast(24);
        updateWeeklyForecast();
        updateBackground(currentData.weather[0].main.toLowerCase());
        updateLastUpdated();
        updateRadar();
        
    } catch (error) {
        console.error('Error:', error);
        showError(`Error: ${error.message}`);
        resetUI();
    }
}

async function geocodeLocation(query) {
    if (geocodingCache[query.toLowerCase()]) {
        return geocodingCache[query.toLowerCase()];
    }
    
    try {
        const response = await fetch(
            `${geoApiUrl}?q=${encodeURIComponent(query)}&limit=1&appid=${apiKey}`
        );
        
        if (!response.ok) throw new Error('Geocoding failed');
        
        const data = await response.json();
        if (!data || data.length === 0) throw new Error('Location not found');
        
        const result = data[0];
        let locationType = 'City';
        if (!result.state && !result.country) locationType = 'Unknown';
        if (result.name.length < 8 && !result.state) locationType = 'Village';
        
        geocodingCache[query.toLowerCase()] = {
            name: result.name,
            lat: result.lat,
            lon: result.lon,
            country: result.country,
            state: result.state,
            type: locationType
        };
        
        return geocodingCache[query.toLowerCase()];
    } catch (error) {
        console.error('Geocoding error:', error);
        return null;
    }
}

async function searchLocations(query) {
    if (query.length < 2) {
        searchResults.style.display = 'none';
        return;
    }
    
    clearTimeout(searchDebounceTimer);
    searchDebounceTimer = setTimeout(async () => {
        try {
            const response = await fetch(
                `${geoApiUrl}?q=${encodeURIComponent(query)}&limit=10&appid=${apiKey}`
            );
            
            if (!response.ok) throw new Error('Search failed');
            
            const data = await response.json();
            displaySearchResults(data);
        } catch (error) {
            console.error('Search error:', error);
            searchResults.innerHTML = '<div class="search-result-item">Error loading results</div>';
            searchResults.style.display = 'block';
        }
    }, 300);
}

function displaySearchResults(results) {
    searchResults.innerHTML = '';
    
    if (!results || results.length === 0) {
        searchResults.innerHTML = '<div class="search-result-item">No locations found</div>';
        searchResults.style.display = 'block';
        return;
    }
    
    results.forEach(location => {
        const item = document.createElement('div');
        item.className = 'search-result-item';
        
        let locationType = 'City';
        if (!location.state && !location.country) locationType = 'Unknown';
        if (location.name.length < 8 && !location.state) locationType = 'Village';
        
        item.innerHTML = `
            <div class="name">
                ${location.name}
                <span class="location-type">${locationType}</span>
            </div>
            <div class="details">
                <span>${location.state || location.country || 'Unknown region'}</span>
                <span>${location.lat?.toFixed(2) || '--'}°, ${location.lon?.toFixed(2) || '--'}°</span>
            </div>
        `;
        
        item.addEventListener('click', () => {
            searchInput.value = `${location.name}${location.state ? `, ${location.state}` : ''}${location.country ? `, ${location.country}` : ''}`;
            searchResults.style.display = 'none';
            fetchWeatherData({
                name: location.name,
                lat: location.lat,
                lon: location.lon,
                type: locationType
            });
        });
        
        searchResults.appendChild(item);
    });
    
    searchResults.style.display = 'block';
}

// Update Current Weather
function updateCurrentWeather(data) {
    cityName.textContent = `${data.name}, ${data.sys.country || ''}`;
    currentTemp.textContent = Math.round(data.main.temp);
    currentTemp.dataset.celsius = Math.round(data.main.temp);
    weatherDesc.textContent = data.weather[0].description;
    windSpeed.textContent = `${Math.round(data.wind.speed * 3.6)} km/h`;
    humidity.textContent = `${data.main.humidity}%`;
    feelsLike.textContent = `${Math.round(data.main.feels_like)}°C`;
    pressure.textContent = `${data.main.pressure} hPa`;
    
    // Update weather icon from OpenWeatherMap
    const iconCode = data.weather[0].icon;
    weatherIcon.src = `https://openweathermap.org/img/wn/${iconCode}@4x.png`;
    weatherIcon.alt = data.weather[0].description;
    
    // Update date
    const now = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    currentDate.textContent = now.toLocaleDateString('en-US', options);
    
    // Generate weather suggestions
    generateWeatherSuggestions(data);
}

// Generate Weather Suggestions
function generateWeatherSuggestions(weatherData) {
    suggestionsContainer.innerHTML = '';
    
    const weatherCondition = weatherData.weather[0].main.toLowerCase();
    const temperature = weatherData.main.temp;
    const windSpeed = weatherData.wind.speed;
    const humidity = weatherData.main.humidity;
    const feelsLike = weatherData.main.feels_like;
    
    // Clothing suggestions
    let clothingSuggestion = '';
    let clothingIcon = '';
    if (temperature > 30) {
        clothingSuggestion = 'Wear light, breathable clothing. Don\'t forget sunscreen and a hat!';
        clothingIcon = 'fa-tshirt';
    } else if (temperature > 20) {
        clothingSuggestion = 'Light clothing is recommended. A light jacket might be useful in the evening.';
        clothingIcon = 'fa-tshirt';
    } else if (temperature > 10) {
        clothingSuggestion = 'Wear layers. A jacket or sweater would be appropriate.';
        clothingIcon = 'fa-jacket';
    } else {
        clothingSuggestion = 'Bundle up! Wear a warm coat, hat, gloves, and scarf.';
        clothingIcon = 'fa-scarf';
    }
    
    // Activity suggestions
    let activitySuggestion = '';
    let activityIcon = '';
    if (weatherCondition.includes('rain')) {
        activitySuggestion = 'Great day for indoor activities: museums, reading, or movie marathon.';
        activityIcon = 'fa-book';
    } else if (weatherCondition.includes('snow')) {
        activitySuggestion = 'Perfect for winter sports, building a snowman, or cozying up with hot chocolate!';
        activityIcon = 'fa-snowman';
    } else if (weatherCondition.includes('clear') && temperature > 20) {
        activitySuggestion = 'Ideal weather for outdoor activities: hiking, picnics, or beach trips.';
        activityIcon = 'fa-hiking';
    } else if (weatherCondition.includes('cloud')) {
        activitySuggestion = 'Good day for a walk, visiting local attractions, or outdoor dining.';
        activityIcon = 'fa-walking';
    } else {
        activitySuggestion = 'Enjoy your day with your favorite activities!';
        activityIcon = 'fa-smile';
    }
    
    // Health suggestions
    let healthSuggestion = '';
    let healthIcon = '';
    if (humidity > 70) {
        healthSuggestion = 'High humidity today. Stay hydrated and take it easy if you have respiratory issues.';
        healthIcon = 'fa-tint';
    } else if (humidity < 30) {
        healthSuggestion = 'Low humidity. Use moisturizer, drink plenty of water, and consider a humidifier.';
        healthIcon = 'fa-tint-slash';
    } else {
        healthSuggestion = 'Comfortable humidity levels today. Remember to stay hydrated!';
        healthIcon = 'fa-heart';
    }
    
    if (windSpeed > 8) {
        healthSuggestion += ' Windy conditions - protect your eyes if sensitive.';
    }
    
    if (feelsLike > 32) {
        healthSuggestion += ' Extreme heat - limit outdoor activities during peak hours.';
    } else if (feelsLike < 0) {
        healthSuggestion += ' Extreme cold - limit time outdoors and watch for frostbite.';
    }
    
    // Travel suggestions
    let travelSuggestion = '';
    let travelIcon = '';
    if (weatherCondition.includes('fog') || weatherCondition.includes('mist')) {
        travelSuggestion = 'Reduced visibility expected. Drive carefully, use low beams, and allow extra travel time.';
        travelIcon = 'fa-car';
    } else if (weatherCondition.includes('rain')) {
        travelSuggestion = 'Wet roads - drive cautiously, allow extra braking distance, and check your wipers.';
        travelIcon = 'fa-car';
    } else if (weatherCondition.includes('snow') || weatherCondition.includes('ice')) {
        travelSuggestion = 'Slippery conditions. Consider public transport, or if driving, use winter tires and go slow.';
        travelIcon = 'fa-car';
    } else {
        travelSuggestion = 'Good travel conditions today. Safe travels!';
        travelIcon = 'fa-car';
    }
    
    // Create suggestion cards
    const suggestions = [
        { icon: clothingIcon, title: 'Clothing Advice', text: clothingSuggestion },
        { icon: activityIcon, title: 'Activity Ideas', text: activitySuggestion },
        { icon: healthIcon, title: 'Health Tips', text: healthSuggestion },
        { icon: travelIcon, title: 'Travel Advisory', text: travelSuggestion }
    ];
    
    suggestions.forEach(suggestion => {
        const card = document.createElement('div');
        card.className = 'suggestion-card';
        card.innerHTML = `
            <i class="fas ${suggestion.icon}"></i>
            <h4>${suggestion.title}</h4>
            <p>${suggestion.text}</p>
        `;
        suggestionsContainer.appendChild(card);
    });
}

// Update Hourly Forecast
function updateHourlyForecast(hours = 24) {
    if (!forecastData) return;
    
    hourlyForecast.innerHTML = '';
    
    // Calculate how many items to show (3-hour intervals)
    const itemsToShow = Math.min(Math.ceil(hours / 3), 16);
    const hourlyData = forecastData.list.slice(0, itemsToShow);
    
    hourlyData.forEach(hour => {
        const date = new Date(hour.dt * 1000);
        const time = date.toLocaleTimeString([], { hour: '2-digit' });
        const temp = Math.round(hour.main.temp);
        const iconCode = hour.weather[0].icon;
        
        const hourItem = document.createElement('div');
        hourItem.className = 'hour-item';
        hourItem.innerHTML = `
            <div class="hour-time">${time}</div>
            <div class="hour-icon">
                <img src="https://openweathermap.org/img/wn/${iconCode}@2x.png" alt="${hour.weather[0].description}">
            </div>
            <div class="hour-temp">${temp}°</div>
        `;
        
        hourlyForecast.appendChild(hourItem);
    });
}
let watchPositionId = null;
const LOCATION_UPDATE_INTERVAL = 300000; // 5 minutes (in milliseconds)
// Update Weekly Forecast
function updateWeeklyForecast() {
    if (!forecastData) return;
    
    weeklyForecast.innerHTML = '';
    
    // Get one forecast per day at noon (or closest available)
    const dailyData = forecastData.list.filter(item => {
        const date = new Date(item.dt * 1000);
        return date.getHours() >= 11 && date.getHours() <= 13;
    }).slice(0, 7);
    
    dailyData.forEach(day => {
        const date = new Date(day.dt * 1000);
        const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
        const maxTemp = Math.round(day.main.temp_max);
        const minTemp = Math.round(day.main.temp_min);
        const iconCode = day.weather[0].icon;
        
        const dayItem = document.createElement('div');
        dayItem.className = 'day-item';
        dayItem.innerHTML = `
            <div class="day-name">${dayName}</div>
            <div class="day-icon">
                <img src="https://openweathermap.org/img/wn/${iconCode}@2x.png" alt="${day.weather[0].description}">
            </div>
            <div class="day-temps">
                <div class="day-high">${maxTemp}°</div>
                <div class="day-low">${minTemp}°</div>
            </div>
        `;
        
        weeklyForecast.appendChild(dayItem);
    });
}

// Update Background Based on Weather
function updateBackground(weatherCondition) {
    const backgroundQuery = weatherBackgrounds[weatherCondition] || weatherBackgrounds.default;
    backgroundImage.src = `https://source.unsplash.com/random/1920x1080/?${backgroundQuery}`;
}

// Get Location Weather
function getLocationWeather() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            async (position) => {
                const { latitude, longitude } = position.coords;
                try {
                    // First try to get exact location name
                    const reverseResponse = await fetch(
                        `${geoApiReverseUrl}?lat=${latitude}&lon=${longitude}&limit=1&appid=${apiKey}`
                    );
                    
                    let locationName = 'Your Location';
                    if (reverseResponse.ok) {
                        const reverseData = await reverseResponse.json();
                        if (reverseData.length > 0) {
                            locationName = reverseData[0].name;
                            if (reverseData[0].state) {
                                locationName += `, ${reverseData[0].state}`;
                            }
                        }
                    }
                    // Update your existing getLocationWeather function to optionally start live tracking
async function getLocationWeather(startLiveTracking = false) {
    if (!navigator.geolocation) {
        showError('Geolocation is not supported by your browser');
        fetchWeatherData('London');
        return;
    }

    // Show loading state
    cityName.textContent = 'Detecting your location...';
    currentTemp.textContent = '--';
    
    try {
        const position = await new Promise((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            });
        });
        
        const { latitude, longitude } = position.coords;
        
        // Get location name
        let locationName = 'Your Location';
        try {
            const reverseResponse = await fetch(
                `${geoApiReverseUrl}?lat=${latitude}&lon=${longitude}&limit=1&appid=${apiKey}`
            );
            
            if (reverseResponse.ok) {
                const reverseData = await reverseResponse.json();
                if (reverseData.length > 0) {
                    locationName = reverseData[0].name;
                    if (reverseData[0].state) {
                        locationName += `, ${reverseData[0].state}`;
                    }
                    if (reverseData[0].country) {
                        locationName += `, ${reverseData[0].country}`;
                    }
                }
            }
        } catch (error) {
            console.log('Reverse geocoding failed, using coordinates', error);
            locationName = `${latitude.toFixed(4)}°, ${longitude.toFixed(4)}°`;
        }
        
        fetchWeatherData({
            name: startLiveTracking ? `${locationName} (Live)` : locationName,
            lat: latitude,
            lon: longitude
        });

        if (startLiveTracking) {
            initLiveLocation();
        }
        
    } catch (error) {
        console.error('Geolocation error:', error);
        showError('Unable to get your location. Defaulting to London.');
        fetchWeatherData('London');
    }
}
                    fetchWeatherData({
                        name: locationName,
                        lat: latitude,
                        lon: longitude
                    });
                } catch (error) {
                    showError('Error getting location weather: ' + error.message);
                }
            },
            (error) => {
                showError('Geolocation error: ' + error.message);
            }
        );
    } else {
        showError('Geolocation is not supported by your browser');
    }
}

// Toggle Temperature Unit
function toggleTemperatureUnit() {
    currentUnit = currentUnit === 'celsius' ? 'fahrenheit' : 'celsius';
    unitToggle.textContent = currentUnit === 'celsius' ? '°C/°F' : '°F/°C';
    convertAllTemperatures();
}

function convertAllTemperatures() {
    // Current temp
    const currentTempElement = document.getElementById('current-temp');
    const currentTempC = parseFloat(currentTempElement.dataset.celsius);
    currentTempElement.textContent = currentUnit === 'celsius' 
        ? Math.round(currentTempC) 
        : Math.round((currentTempC * 9/5) + 32);
    
    // Feels like
    const feelsLikeElement = document.getElementById('feels-like');
    const feelsLikeText = feelsLikeElement.textContent;
    const feelsLikeC = parseFloat(feelsLikeText);
    if (!isNaN(feelsLikeC)) {
        feelsLikeElement.textContent = currentUnit === 'celsius' 
            ? `${Math.round(feelsLikeC)}°C` 
            : `${Math.round((feelsLikeC * 9/5) + 32)}°F`;
    }
    
    // Hourly forecast
    document.querySelectorAll('.hour-temp').forEach(element => {
        const tempText = element.textContent;
        const tempC = parseFloat(tempText);
        if (!isNaN(tempC)) {
            element.textContent = currentUnit === 'celsius' 
                ? `${Math.round(tempC)}°` 
                : `${Math.round((tempC * 9/5) + 32)}°`;
        }
    });
    
    // Weekly forecast
    document.querySelectorAll('.day-high, .day-low').forEach(element => {
        const tempText = element.textContent;
        const tempC = parseFloat(tempText);
        if (!isNaN(tempC)) {
            element.textContent = currentUnit === 'celsius' 
                ? `${Math.round(tempC)}°` 
                : `${Math.round((tempC * 9/5) + 32)}°`;
        }
    });
}

// Update Last Updated Time
function updateLastUpdated() {
    const now = new Date();
    lastUpdated.textContent = `Last updated: ${now.toLocaleTimeString()}`;
}

// Show Error Message
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    document.body.prepend(errorDiv);
    
    setTimeout(() => {
        errorDiv.remove();
    }, 5000);
}

// Reset UI when errors occur
function resetUI() {
    cityName.textContent = 'WeatherPulse';
    currentTemp.textContent = '--';
    weatherDesc.textContent = 'Search for a city';
    hourlyForecast.innerHTML = '<div class="error-message">No forecast data available</div>';
    weeklyForecast.innerHTML = '<div class="error-message">No forecast data available</div>';
    suggestionsContainer.innerHTML = '<div class="error-message">No suggestions available</div>';
    lastUpdated.textContent = 'Last updated: --';
    backgroundImage.src = 'https://source.unsplash.com/random/1920x1080/?weather,landscape';
    weatherIcon.src = 'https://openweathermap.org/img/wn/01d@4x.png';
}

// Handle broken images
document.querySelectorAll('img').forEach(img => {
    img.onerror = function() {
        if (this.id === 'weather-icon') {
            this.src = 'https://openweathermap.org/img/wn/01d@4x.png';
        } else if (this.classList.contains('hour-icon') || this.classList.contains('day-icon')) {
            this.src = 'https://openweathermap.org/img/wn/02d@2x.png';
        } else if (this.id === 'background-image') {
            this.src = 'https://source.unsplash.com/random/1920x1080/?weather,landscape';
        }
    };
});

function updateRadar() {
    const radarType = radarTypeSelect.value;
    const city = currentCity || 'London';
    
    let radarUrl = '';
    
    switch(radarType) {
        case 'precipitation':
            radarUrl = `https://embed.windy.com/embed2.html?lat=${forecastData?.city?.coord?.lat || 51.5074}&lon=${forecastData?.city?.coord?.lon || -0.1278}&zoom=5&level=surface&overlay=rain&product=radar&menu=&message=true&marker=&calendar=now&pressure=&type=map&location=coordinates&detail=${encodeURIComponent(city)}&metricWind=km%2Fh&metricTemp=%C2%B0C`;
            break;
        case 'clouds':
            radarUrl = `https://embed.windy.com/embed2.html?lat=${forecastData?.city?.coord?.lat || 51.5074}&lon=${forecastData?.city?.coord?.lon || -0.1278}&zoom=5&level=surface&overlay=clouds&product=ecmwf&menu=&message=true&marker=&calendar=now&pressure=&type=map&location=coordinates&detail=${encodeURIComponent(city)}&metricWind=km%2Fh&metricTemp=%C2%B0C`;
            break;
        case 'temperature':
            radarUrl = `https://embed.windy.com/embed2.html?lat=${forecastData?.city?.coord?.lat || 51.5074}&lon=${forecastData?.city?.coord?.lon || -0.1278}&zoom=5&level=surface&overlay=temp&product=ecmwf&menu=&message=true&marker=&calendar=now&pressure=&type=map&location=coordinates&detail=${encodeURIComponent(city)}&metricWind=km%2Fh&metricTemp=%C2%B0C`;
            break;
        default:
            radarUrl = `https://embed.windy.com/embed2.html?lat=${forecastData?.city?.coord?.lat || 51.5074}&lon=${forecastData?.city?.coord?.lon || -0.1278}&zoom=5&level=surface&overlay=rain&product=radar&menu=&message=true&marker=&calendar=now&pressure=&type=map&location=coordinates&detail=${encodeURIComponent(city)}&metricWind=km%2Fh&metricTemp=%C2%B0C`;
    }
    
    weatherRadar.src = radarUrl;
}

function toggleRadarAnimation() {
    if (isRadarAnimating) {
        stopRadarAnimation();
    } else {
        startRadarAnimation();
    }
}

function startRadarAnimation() {
    isRadarAnimating = true;
    radarAnimateBtn.textContent = 'Stop Animation';
    
    // This is a simple simulation - in a real app you might use a more sophisticated approach
    radarAnimationInterval = setInterval(() => {
        const currentSrc = weatherRadar.src;
        if (currentSrc.includes('windy.com')) {
            weatherRadar.src = currentSrc.includes('radar') 
                ? currentSrc.replace(/(level=)\w+/, '$1' + ['surface', '500h', '850h'][Math.floor(Math.random() * 3)])
                : currentSrc.replace(/(zoom=)\d+/, '$1' + (5 + Math.floor(Math.random() * 3)));
        }
    }, 2000);
}

function stopRadarAnimation() {
    isRadarAnimating = false;
    radarAnimateBtn.textContent = 'Play Animation';
    clearInterval(radarAnimationInterval);
}
function initLiveLocation() {
    if (!navigator.geolocation) {
        showError('Geolocation is not supported by your browser');
        return;
    }

    // Start watching position
    watchPositionId = navigator.geolocation.watchPosition(
        handlePositionUpdate,
        handlePositionError,
        {
            enableHighAccuracy: true,
            maximumAge: 30000,
            timeout: 10000
        }
    );

    liveLocationIndicator.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Live';
    liveLocationToggle.checked = true;
}

// Handle position updates
async function handlePositionUpdate(position) {
    const { latitude, longitude } = position.coords;
    
    try {
        // Get location name
        let locationName = 'Your Location';
        const reverseResponse = await fetch(
            `${geoApiReverseUrl}?lat=${latitude}&lon=${longitude}&limit=1&appid=${apiKey}`
        );
        
        if (reverseResponse.ok) {
            const reverseData = await reverseResponse.json();
            if (reverseData.length > 0) {
                locationName = reverseData[0].name;
                if (reverseData[0].state) {
                    locationName += `, ${reverseData[0].state}`;
                }
                if (reverseData[0].country) {
                    locationName += `, ${reverseData[0].country}`;
                }
            }
        }

        // Update weather data
        fetchWeatherData({
            name: `${locationName} (Live)`,
            lat: latitude,
            lon: longitude
        });

        // Update last updated time
        updateLastUpdated();

    } catch (error) {
        console.error('Error updating live location:', error);
        showError('Error updating live location data');
    }
}

// Handle position errors
function handlePositionError(error) {
    console.error('Geolocation error:', error);
    stopLiveLocation();
    showError('Live location tracking failed: ' + error.message);
}

// Stop live location tracking
function stopLiveLocation() {
    if (watchPositionId) {
        navigator.geolocation.clearWatch(watchPositionId);
        watchPositionId = null;
    }
    liveLocationIndicator.textContent = 'Off';
    liveLocationToggle.checked = false;
}

// Toggle live location
function toggleLiveLocation() {
    if (liveLocationToggle.checked) {
        initLiveLocation();
    } else {
        stopLiveLocation();
    }
}